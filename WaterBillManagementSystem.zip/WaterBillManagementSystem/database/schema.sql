-- Water Bill Management System - MySQL schema + predefined rates
CREATE DATABASE IF NOT EXISTS water_bill_db;
USE water_bill_db;

CREATE TABLE IF NOT EXISTS customers (
    customer_id     INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    address         VARCHAR(255) NOT NULL,
    phone           VARCHAR(15)  NOT NULL,
    meter_no        VARCHAR(30)  NOT NULL UNIQUE,
    connection_type ENUM('DOMESTIC','COMMERCIAL','INDUSTRIAL') NOT NULL DEFAULT 'DOMESTIC',
    initial_reading INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Slab based tariff: units in (slab_from, slab_to] are charged at rate_per_unit.
-- slab_to = NULL means "no upper limit".
CREATE TABLE IF NOT EXISTS rates (
    rate_id         INT AUTO_INCREMENT PRIMARY KEY,
    connection_type ENUM('DOMESTIC','COMMERCIAL','INDUSTRIAL') NOT NULL,
    slab_from       INT NOT NULL,
    slab_to         INT NULL,
    rate_per_unit   DECIMAL(10,2) NOT NULL,
    UNIQUE KEY uq_rate_slab (connection_type, slab_from)
);

-- Fixed monthly charge added to every bill
CREATE TABLE IF NOT EXISTS service_charges (
    connection_type ENUM('DOMESTIC','COMMERCIAL','INDUSTRIAL') PRIMARY KEY,
    charge          DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS bills (
    bill_id          INT AUTO_INCREMENT PRIMARY KEY,
    customer_id      INT NOT NULL,
    bill_month       TINYINT  NOT NULL,
    bill_year        SMALLINT NOT NULL,
    previous_reading INT NOT NULL,
    current_reading  INT NOT NULL,
    units_consumed   INT NOT NULL,
    water_charge     DECIMAL(12,2) NOT NULL,
    service_charge   DECIMAL(10,2) NOT NULL,
    total_amount     DECIMAL(12,2) NOT NULL,
    status           ENUM('UNPAID','PAID') NOT NULL DEFAULT 'UNPAID',
    paid_date        DATE NULL,
    generated_on     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_customer_period (customer_id, bill_month, bill_year),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
);

-- Predefined rates (edit these values to change the tariff)
INSERT IGNORE INTO rates (connection_type, slab_from, slab_to, rate_per_unit) VALUES
 ('DOMESTIC',   0,   100,  5.00),
 ('DOMESTIC',   100, 300,  8.00),
 ('DOMESTIC',   300, NULL, 12.00),
 ('COMMERCIAL', 0,   100,  10.00),
 ('COMMERCIAL', 100, 300,  15.00),
 ('COMMERCIAL', 300, NULL, 20.00),
 ('INDUSTRIAL', 0,   100,  15.00),
 ('INDUSTRIAL', 100, 500,  22.00),
 ('INDUSTRIAL', 500, NULL, 30.00);

INSERT IGNORE INTO service_charges (connection_type, charge) VALUES
 ('DOMESTIC', 50.00), ('COMMERCIAL', 150.00), ('INDUSTRIAL', 300.00);
