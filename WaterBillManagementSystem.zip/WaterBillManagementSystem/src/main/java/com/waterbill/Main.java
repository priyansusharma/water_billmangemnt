package com.waterbill;

import com.waterbill.db.DBConnection;
import com.waterbill.ui.MainFrame;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.sql.SQLException;

public class Main {

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            // fall back to the default look and feel
        }

        SwingUtilities.invokeLater(() -> {
            try {
                DBConnection.getConnection().close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,
                        "Could not connect to MySQL.\n\n" + e.getMessage()
                                + "\n\nCheck src/main/resources/db.properties and make sure"
                                + "\ndatabase/schema.sql has been executed.",
                        "Database Error", JOptionPane.ERROR_MESSAGE);
                System.exit(1);
            }
            new MainFrame().setVisible(true);
        });
    }
}
