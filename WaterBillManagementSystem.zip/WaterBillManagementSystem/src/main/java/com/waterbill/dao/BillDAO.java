package com.waterbill.dao;

import com.waterbill.db.DBConnection;
import com.waterbill.model.Bill;
import com.waterbill.model.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class BillDAO {

    /** Last billed meter reading, or the customer's initial reading if no bill exists yet. */
    public int getPreviousReading(Customer c) throws SQLException {
        String sql = "SELECT current_reading FROM bills WHERE customer_id=? "
                + "ORDER BY bill_year DESC, bill_month DESC LIMIT 1";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, c.getId());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return c.getInitialReading();
    }

    public boolean exists(int customerId, int month, int year) throws SQLException {
        String sql = "SELECT 1 FROM bills WHERE customer_id=? AND bill_month=? AND bill_year=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, customerId);
            ps.setInt(2, month);
            ps.setInt(3, year);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Inserts the bill and returns the generated bill id. */
    public int insert(Bill b) throws SQLException {
        String sql = "INSERT INTO bills (customer_id, bill_month, bill_year, previous_reading, current_reading, "
                + "units_consumed, water_charge, service_charge, total_amount, status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'UNPAID')";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, b.getCustomerId());
            ps.setInt(2, b.getMonth());
            ps.setInt(3, b.getYear());
            ps.setInt(4, b.getPreviousReading());
            ps.setInt(5, b.getCurrentReading());
            ps.setInt(6, b.getUnitsConsumed());
            ps.setBigDecimal(7, b.getWaterCharge());
            ps.setBigDecimal(8, b.getServiceCharge());
            ps.setBigDecimal(9, b.getTotalAmount());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getInt(1) : 0;
            }
        }
    }

    /** Searches bills by customer name / meter no / customer id and by status (ALL, UNPAID, PAID). */
    public List<Bill> search(String keyword, String status) throws SQLException {
        String kw = keyword == null ? "" : keyword.trim();
        String sql = "SELECT b.*, c.name, c.meter_no, c.connection_type FROM bills b "
                + "JOIN customers c ON b.customer_id = c.customer_id "
                + "WHERE (c.name LIKE ? OR c.meter_no LIKE ? OR CAST(c.customer_id AS CHAR) = ?) "
                + "AND (? = 'ALL' OR b.status = ?) "
                + "ORDER BY b.bill_year DESC, b.bill_month DESC, b.bill_id DESC";
        List<Bill> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + kw + "%");
            ps.setString(2, "%" + kw + "%");
            ps.setString(3, kw);
            ps.setString(4, status);
            ps.setString(5, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Bill b = new Bill();
                    b.setId(rs.getInt("bill_id"));
                    b.setCustomerId(rs.getInt("customer_id"));
                    b.setCustomerName(rs.getString("name"));
                    b.setMeterNo(rs.getString("meter_no"));
                    b.setConnectionType(rs.getString("connection_type"));
                    b.setMonth(rs.getInt("bill_month"));
                    b.setYear(rs.getInt("bill_year"));
                    b.setPreviousReading(rs.getInt("previous_reading"));
                    b.setCurrentReading(rs.getInt("current_reading"));
                    b.setUnitsConsumed(rs.getInt("units_consumed"));
                    b.setWaterCharge(rs.getBigDecimal("water_charge"));
                    b.setServiceCharge(rs.getBigDecimal("service_charge"));
                    b.setTotalAmount(rs.getBigDecimal("total_amount"));
                    b.setStatus(rs.getString("status"));
                    b.setPaidDate(rs.getDate("paid_date"));
                    list.add(b);
                }
            }
        }
        return list;
    }

    /** Marks an unpaid bill as paid today. Returns false if it was already paid. */
    public boolean markPaid(int billId) throws SQLException {
        String sql = "UPDATE bills SET status='PAID', paid_date=CURDATE() WHERE bill_id=? AND status='UNPAID'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, billId);
            return ps.executeUpdate() > 0;
        }
    }
}
