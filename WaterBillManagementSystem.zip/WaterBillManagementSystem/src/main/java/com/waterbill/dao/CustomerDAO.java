package com.waterbill.dao;

import com.waterbill.db.DBConnection;
import com.waterbill.model.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {

    public void add(Customer c) throws SQLException {
        String sql = "INSERT INTO customers (name, address, phone, meter_no, connection_type, initial_reading) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getAddress());
            ps.setString(3, c.getPhone());
            ps.setString(4, c.getMeterNo());
            ps.setString(5, c.getConnectionType());
            ps.setInt(6, c.getInitialReading());
            ps.executeUpdate();
        }
    }

    public void update(Customer c) throws SQLException {
        String sql = "UPDATE customers SET name=?, address=?, phone=?, meter_no=?, connection_type=?, "
                + "initial_reading=? WHERE customer_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getAddress());
            ps.setString(3, c.getPhone());
            ps.setString(4, c.getMeterNo());
            ps.setString(5, c.getConnectionType());
            ps.setInt(6, c.getInitialReading());
            ps.setInt(7, c.getId());
            ps.executeUpdate();
        }
    }

    /** Deletes the customer and (via ON DELETE CASCADE) all of their bills. */
    public void delete(int customerId) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM customers WHERE customer_id=?")) {
            ps.setInt(1, customerId);
            ps.executeUpdate();
        }
    }

    public List<Customer> getAll() throws SQLException {
        return search(null);
    }

    /** Searches by name, meter number or customer id. A null/blank keyword returns everyone. */
    public List<Customer> search(String keyword) throws SQLException {
        boolean all = keyword == null || keyword.trim().isEmpty();
        String sql = "SELECT * FROM customers"
                + (all ? "" : " WHERE name LIKE ? OR meter_no LIKE ? OR CAST(customer_id AS CHAR) = ?")
                + " ORDER BY customer_id";
        List<Customer> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            if (!all) {
                String kw = keyword.trim();
                ps.setString(1, "%" + kw + "%");
                ps.setString(2, "%" + kw + "%");
                ps.setString(3, kw);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Customer(
                            rs.getInt("customer_id"),
                            rs.getString("name"),
                            rs.getString("address"),
                            rs.getString("phone"),
                            rs.getString("meter_no"),
                            rs.getString("connection_type"),
                            rs.getInt("initial_reading")));
                }
            }
        }
        return list;
    }
}
