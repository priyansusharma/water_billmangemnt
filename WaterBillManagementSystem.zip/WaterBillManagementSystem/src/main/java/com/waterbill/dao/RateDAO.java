package com.waterbill.dao;

import com.waterbill.db.DBConnection;
import com.waterbill.model.Slab;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Reads the predefined tariff (slab rates and fixed service charges). */
public class RateDAO {

    public List<Slab> getSlabs(String connectionType) throws SQLException {
        List<Slab> list = new ArrayList<>();
        String sql = "SELECT * FROM rates WHERE connection_type=? ORDER BY slab_from";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, connectionType);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapSlab(rs));
                }
            }
        }
        return list;
    }

    public List<Slab> getAllSlabs() throws SQLException {
        List<Slab> list = new ArrayList<>();
        String sql = "SELECT * FROM rates ORDER BY connection_type, slab_from";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapSlab(rs));
            }
        }
        return list;
    }

    public BigDecimal getServiceCharge(String connectionType) throws SQLException {
        String sql = "SELECT charge FROM service_charges WHERE connection_type=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, connectionType);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getBigDecimal(1);
                }
            }
        }
        return BigDecimal.ZERO;
    }

    public Map<String, BigDecimal> getAllServiceCharges() throws SQLException {
        Map<String, BigDecimal> map = new LinkedHashMap<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM service_charges ORDER BY connection_type")) {
            while (rs.next()) {
                map.put(rs.getString("connection_type"), rs.getBigDecimal("charge"));
            }
        }
        return map;
    }

    private Slab mapSlab(ResultSet rs) throws SQLException {
        int toVal = rs.getInt("slab_to");
        Integer to = rs.wasNull() ? null : toVal;
        return new Slab(rs.getString("connection_type"), rs.getInt("slab_from"), to,
                rs.getBigDecimal("rate_per_unit"));
    }
}
