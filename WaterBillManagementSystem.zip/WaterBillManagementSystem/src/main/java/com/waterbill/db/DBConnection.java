package com.waterbill.db;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/** Creates JDBC connections using the settings in db.properties. */
public class DBConnection {

    private static final Properties PROPS = new Properties();

    static {
        try (InputStream in = DBConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) {
                PROPS.load(in);
            }
        } catch (IOException e) {
            System.err.println("Could not read db.properties: " + e.getMessage());
        }
    }

    private DBConnection() {
    }

    public static Connection getConnection() throws SQLException {
        String url = PROPS.getProperty("db.url",
                "jdbc:mysql://localhost:3306/water_bill_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
        String user = PROPS.getProperty("db.user", "root");
        String password = PROPS.getProperty("db.password", "");
        return DriverManager.getConnection(url, user, password);
    }
}
