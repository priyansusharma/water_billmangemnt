package com.waterbill.model;

public class Customer {
    private int id;
    private String name;
    private String address;
    private String phone;
    private String meterNo;
    private String connectionType;
    private int initialReading;

    public Customer() {
    }

    public Customer(int id, String name, String address, String phone,
                    String meterNo, String connectionType, int initialReading) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.meterNo = meterNo;
        this.connectionType = connectionType;
        this.initialReading = initialReading;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getMeterNo() { return meterNo; }
    public void setMeterNo(String meterNo) { this.meterNo = meterNo; }
    public String getConnectionType() { return connectionType; }
    public void setConnectionType(String connectionType) { this.connectionType = connectionType; }
    public int getInitialReading() { return initialReading; }
    public void setInitialReading(int initialReading) { this.initialReading = initialReading; }

    @Override
    public String toString() {
        return id + " - " + name + " (" + meterNo + ")";
    }
}
