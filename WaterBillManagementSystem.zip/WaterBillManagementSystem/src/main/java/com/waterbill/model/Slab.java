package com.waterbill.model;

import java.math.BigDecimal;

/** One tariff slab: units above 'from' up to 'to' (null = unlimited) cost 'rate' each. */
public class Slab {
    private final String connectionType;
    private final int from;
    private final Integer to;
    private final BigDecimal rate;

    public Slab(String connectionType, int from, Integer to, BigDecimal rate) {
        this.connectionType = connectionType;
        this.from = from;
        this.to = to;
        this.rate = rate;
    }

    public String getConnectionType() { return connectionType; }
    public int getFrom() { return from; }
    public Integer getTo() { return to; }
    public BigDecimal getRate() { return rate; }
}
