package com.waterbill.ui;

import com.waterbill.dao.BillDAO;
import com.waterbill.dao.CustomerDAO;
import com.waterbill.dao.RateDAO;
import com.waterbill.model.Bill;
import com.waterbill.model.Customer;
import com.waterbill.model.Slab;
import com.waterbill.util.BillCalculator;
import com.waterbill.util.BillFormatter;
import com.waterbill.util.Dialogs;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/** Enter the current meter reading, preview the bill and generate it. */
public class BillingPanel extends JPanel implements Refreshable {

    private static final String[] MONTHS = {"January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"};

    private final CustomerDAO customerDao = new CustomerDAO();
    private final BillDAO billDao = new BillDAO();
    private final RateDAO rateDao = new RateDAO();

    private final JComboBox<Customer> cmbCustomer = new JComboBox<>();
    private final JLabel lblType = new JLabel("-");
    private final JLabel lblPrev = new JLabel("-");
    private final JTextField txtCurrent = new JTextField(10);
    private final JComboBox<String> cmbMonth = new JComboBox<>(MONTHS);
    private final JSpinner spnYear;
    private final JTextArea area = new JTextArea();
    private boolean loading = false;

    public BillingPanel() {
        setLayout(new BorderLayout(8, 8));
        setBorder(new EmptyBorder(10, 10, 10, 10));

        int year = LocalDate.now().getYear();
        spnYear = new JSpinner(new SpinnerNumberModel(year, 2000, 2100, 1));
        spnYear.setEditor(new JSpinner.NumberEditor(spnYear, "#"));
        cmbMonth.setSelectedIndex(LocalDate.now().getMonthValue() - 1);

        add(buildForm(), BorderLayout.NORTH);

        area.setEditable(false);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JScrollPane sp = new JScrollPane(area);
        sp.setBorder(BorderFactory.createTitledBorder("Bill"));
        add(sp, BorderLayout.CENTER);

        cmbCustomer.addActionListener(e -> {
            if (!loading) {
                onCustomerChanged();
            }
        });
        loadCustomers();
    }

    private JPanel buildForm() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder("Meter Reading Entry"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 6, 5, 6);
        g.anchor = GridBagConstraints.WEST;

        add(p, g, 0, 0, "Customer", cmbCustomer);
        add(p, g, 0, 2, "Connection Type", lblType);
        add(p, g, 1, 0, "Billing Month", cmbMonth);
        add(p, g, 1, 2, "Billing Year", spnYear);
        add(p, g, 2, 0, "Previous Reading", lblPrev);
        add(p, g, 2, 2, "Current Reading *", txtCurrent);

        JButton btnPreview = new JButton("Calculate / Preview");
        JButton btnGenerate = new JButton("Generate Bill");
        btnPreview.addActionListener(e -> preview());
        btnGenerate.addActionListener(e -> generate());
        JPanel buttons = new JPanel();
        buttons.add(btnPreview);
        buttons.add(btnGenerate);
        g.gridy = 3;
        g.gridx = 0;
        g.gridwidth = 4;
        g.fill = GridBagConstraints.HORIZONTAL;
        p.add(buttons, g);
        return p;
    }

    private void add(JPanel p, GridBagConstraints g, int row, int col, String label, java.awt.Component field) {
        g.gridy = row;
        g.gridwidth = 1;
        g.fill = GridBagConstraints.NONE;
        g.gridx = col;
        p.add(new JLabel(label), g);
        g.gridx = col + 1;
        p.add(field, g);
    }

    private void loadCustomers() {
        Customer previous = (Customer) cmbCustomer.getSelectedItem();
        loading = true;
        try {
            List<Customer> list = customerDao.getAll();
            cmbCustomer.removeAllItems();
            Customer toSelect = null;
            for (Customer c : list) {
                cmbCustomer.addItem(c);
                if (previous != null && previous.getId() == c.getId()) {
                    toSelect = c;
                }
            }
            if (toSelect != null) {
                cmbCustomer.setSelectedItem(toSelect);
            }
        } catch (SQLException e) {
            Dialogs.error(this, e);
        } finally {
            loading = false;
        }
        onCustomerChanged();
    }

    private void onCustomerChanged() {
        Customer c = (Customer) cmbCustomer.getSelectedItem();
        if (c == null) {
            lblType.setText("-");
            lblPrev.setText("-");
            return;
        }
        lblType.setText(c.getConnectionType());
        try {
            lblPrev.setText(String.valueOf(billDao.getPreviousReading(c)));
        } catch (SQLException e) {
            Dialogs.error(this, e);
        }
    }

    /** Validates input and builds the bill (not saved yet). Returns null on invalid input. */
    private Bill buildBill() {
        Customer c = (Customer) cmbCustomer.getSelectedItem();
        if (c == null) {
            Dialogs.warn(this, "Add a customer first (Customers tab).");
            return null;
        }
        int current;
        try {
            current = Integer.parseInt(txtCurrent.getText().trim());
        } catch (NumberFormatException e) {
            Dialogs.warn(this, "Enter the current meter reading as a whole number.");
            return null;
        }
        try {
            int previous = billDao.getPreviousReading(c);
            if (current < previous) {
                Dialogs.warn(this, "Current reading (" + current + ") cannot be less than the previous reading ("
                        + previous + ").");
                return null;
            }
            int units = current - previous;
            List<Slab> slabs = rateDao.getSlabs(c.getConnectionType());
            BigDecimal water = BillCalculator.waterCharge(units, slabs);
            BigDecimal service = rateDao.getServiceCharge(c.getConnectionType());

            Bill b = new Bill();
            b.setCustomerId(c.getId());
            b.setCustomerName(c.getName());
            b.setMeterNo(c.getMeterNo());
            b.setConnectionType(c.getConnectionType());
            b.setMonth(cmbMonth.getSelectedIndex() + 1);
            b.setYear((Integer) spnYear.getValue());
            b.setPreviousReading(previous);
            b.setCurrentReading(current);
            b.setUnitsConsumed(units);
            b.setWaterCharge(water);
            b.setServiceCharge(service);
            b.setTotalAmount(water.add(service));
            return b;
        } catch (SQLException e) {
            Dialogs.error(this, e);
            return null;
        }
    }

    private void preview() {
        Bill b = buildBill();
        if (b != null) {
            area.setText("PREVIEW (not saved)\n" + BillFormatter.format(b));
        }
    }

    private void generate() {
        Bill b = buildBill();
        if (b == null) {
            return;
        }
        try {
            if (billDao.exists(b.getCustomerId(), b.getMonth(), b.getYear())) {
                Dialogs.warn(this, "A bill for " + BillFormatter.monthName(b.getMonth()) + " " + b.getYear()
                        + " already exists for this customer.");
                return;
            }
            b.setId(billDao.insert(b));
            area.setText(BillFormatter.format(b));
            txtCurrent.setText("");
            onCustomerChanged();
            Dialogs.info(this, "Bill generated. Total: Rs. " + b.getTotalAmount());
        } catch (SQLException e) {
            Dialogs.error(this, e);
        }
    }

    @Override
    public void refresh() {
        loadCustomers();
    }
}
