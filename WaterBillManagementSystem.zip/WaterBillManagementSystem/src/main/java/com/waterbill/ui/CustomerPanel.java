package com.waterbill.ui;

import com.waterbill.dao.CustomerDAO;
import com.waterbill.model.Customer;
import com.waterbill.util.Dialogs;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

/** Add / update / delete / search customer records. */
public class CustomerPanel extends JPanel implements Refreshable {

    private final CustomerDAO dao = new CustomerDAO();

    private final JTextField txtName = new JTextField(18);
    private final JTextField txtAddress = new JTextField(18);
    private final JTextField txtPhone = new JTextField(18);
    private final JTextField txtMeter = new JTextField(18);
    private final JTextField txtInitial = new JTextField("0", 18);
    private final JComboBox<String> cmbType =
            new JComboBox<>(new String[]{"DOMESTIC", "COMMERCIAL", "INDUSTRIAL"});
    private final JTextField txtSearch = new JTextField(18);

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Name", "Address", "Phone", "Meter No", "Type", "Initial Reading"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(model);
    private int selectedId = -1;

    public CustomerPanel() {
        setLayout(new BorderLayout(8, 8));
        setBorder(new EmptyBorder(10, 10, 10, 10));
        add(buildForm(), BorderLayout.NORTH);
        add(buildTablePanel(), BorderLayout.CENTER);
        loadTable();
    }

    private JPanel buildForm() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder("Customer Details"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);
        g.anchor = GridBagConstraints.WEST;

        addRow(p, g, 0, 0, "Name *", txtName);
        addRow(p, g, 0, 2, "Address *", txtAddress);
        addRow(p, g, 1, 0, "Phone (10 digits) *", txtPhone);
        addRow(p, g, 1, 2, "Meter No *", txtMeter);
        addRow(p, g, 2, 0, "Connection Type", cmbType);
        addRow(p, g, 2, 2, "Initial Meter Reading", txtInitial);

        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnClear = new JButton("Clear");
        btnAdd.addActionListener(e -> addCustomer());
        btnUpdate.addActionListener(e -> updateCustomer());
        btnDelete.addActionListener(e -> deleteCustomer());
        btnClear.addActionListener(e -> clearForm());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 4));
        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);
        g.gridy = 3;
        g.gridx = 0;
        g.gridwidth = 4;
        g.fill = GridBagConstraints.HORIZONTAL;
        p.add(buttons, g);
        return p;
    }

    private void addRow(JPanel p, GridBagConstraints g, int row, int col, String label, JComponent field) {
        g.gridy = row;
        g.gridwidth = 1;
        g.gridx = col;
        p.add(new JLabel(label), g);
        g.gridx = col + 1;
        p.add(field, g);
    }

    private JPanel buildTablePanel() {
        JPanel p = new JPanel(new BorderLayout(6, 6));

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        JButton btnSearch = new JButton("Search");
        JButton btnAll = new JButton("Show All");
        searchBar.add(new JLabel("Search (name / meter no / id):"));
        searchBar.add(txtSearch);
        searchBar.add(btnSearch);
        searchBar.add(btnAll);
        btnSearch.addActionListener(e -> loadTable());
        txtSearch.addActionListener(e -> loadTable());
        btnAll.addActionListener(e -> {
            txtSearch.setText("");
            loadTable();
        });

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.setRowHeight(22);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFormFromSelection();
            }
        });

        p.add(searchBar, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        return p;
    }

    private void loadTable() {
        try {
            List<Customer> list = dao.search(txtSearch.getText());
            model.setRowCount(0);
            for (Customer c : list) {
                model.addRow(new Object[]{c.getId(), c.getName(), c.getAddress(), c.getPhone(),
                        c.getMeterNo(), c.getConnectionType(), c.getInitialReading()});
            }
        } catch (SQLException e) {
            Dialogs.error(this, e);
        }
    }

    private void fillFormFromSelection() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }
        int m = table.convertRowIndexToModel(row);
        selectedId = (Integer) model.getValueAt(m, 0);
        txtName.setText(String.valueOf(model.getValueAt(m, 1)));
        txtAddress.setText(String.valueOf(model.getValueAt(m, 2)));
        txtPhone.setText(String.valueOf(model.getValueAt(m, 3)));
        txtMeter.setText(String.valueOf(model.getValueAt(m, 4)));
        cmbType.setSelectedItem(model.getValueAt(m, 5));
        txtInitial.setText(String.valueOf(model.getValueAt(m, 6)));
    }

    private void clearForm() {
        selectedId = -1;
        txtName.setText("");
        txtAddress.setText("");
        txtPhone.setText("");
        txtMeter.setText("");
        txtInitial.setText("0");
        cmbType.setSelectedIndex(0);
        table.clearSelection();
    }

    /** Validates the form; returns null (after showing a message) when something is wrong. */
    private Customer readForm() {
        String name = txtName.getText().trim();
        String address = txtAddress.getText().trim();
        String phone = txtPhone.getText().trim();
        String meter = txtMeter.getText().trim();
        if (name.isEmpty() || address.isEmpty() || meter.isEmpty()) {
            Dialogs.warn(this, "Name, Address and Meter No are required.");
            return null;
        }
        if (!phone.matches("\\d{10}")) {
            Dialogs.warn(this, "Phone number must be exactly 10 digits.");
            return null;
        }
        int initial;
        try {
            initial = Integer.parseInt(txtInitial.getText().trim());
            if (initial < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            Dialogs.warn(this, "Initial meter reading must be a whole number (0 or more).");
            return null;
        }
        return new Customer(selectedId, name, address, phone, meter,
                (String) cmbType.getSelectedItem(), initial);
    }

    private void addCustomer() {
        Customer c = readForm();
        if (c == null) {
            return;
        }
        try {
            dao.add(c);
            Dialogs.info(this, "Customer added successfully.");
            clearForm();
            loadTable();
        } catch (SQLIntegrityConstraintViolationException e) {
            Dialogs.warn(this, "A customer with this meter number already exists.");
        } catch (SQLException e) {
            Dialogs.error(this, e);
        }
    }

    private void updateCustomer() {
        if (selectedId < 0) {
            Dialogs.warn(this, "Select a customer from the table first.");
            return;
        }
        Customer c = readForm();
        if (c == null) {
            return;
        }
        try {
            dao.update(c);
            Dialogs.info(this, "Customer updated successfully.");
            clearForm();
            loadTable();
        } catch (SQLIntegrityConstraintViolationException e) {
            Dialogs.warn(this, "Another customer already uses this meter number.");
        } catch (SQLException e) {
            Dialogs.error(this, e);
        }
    }

    private void deleteCustomer() {
        if (selectedId < 0) {
            Dialogs.warn(this, "Select a customer from the table first.");
            return;
        }
        if (!Dialogs.confirm(this, "Delete this customer and ALL of their bills?")) {
            return;
        }
        try {
            dao.delete(selectedId);
            clearForm();
            loadTable();
        } catch (SQLException e) {
            Dialogs.error(this, e);
        }
    }

    @Override
    public void refresh() {
        loadTable();
    }
}
