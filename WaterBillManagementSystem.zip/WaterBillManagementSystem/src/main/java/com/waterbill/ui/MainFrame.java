package com.waterbill.ui;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.Component;

public class MainFrame extends JFrame {

    public MainFrame() {
        super("Water Bill Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1020, 660);
        setMinimumSize(new java.awt.Dimension(900, 600));
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Customers", new CustomerPanel());
        tabs.addTab("Enter Reading / Generate Bill", new BillingPanel());
        tabs.addTab("Bills & Payments", new PaymentPanel());
        tabs.addTab("Tariff (Rates)", new TariffPanel());

        // Reload data whenever the user switches tabs
        tabs.addChangeListener(e -> {
            Component c = tabs.getSelectedComponent();
            if (c instanceof Refreshable) {
                ((Refreshable) c).refresh();
            }
        });

        add(tabs);
    }
}
