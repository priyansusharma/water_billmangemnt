package com.waterbill.ui;

import com.waterbill.dao.BillDAO;
import com.waterbill.model.Bill;
import com.waterbill.util.BillFormatter;
import com.waterbill.util.Dialogs;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Lists bills, shows receipts and records payments. */
public class PaymentPanel extends JPanel implements Refreshable {

    private final BillDAO dao = new BillDAO();

    private final JTextField txtSearch = new JTextField(16);
    private final JComboBox<String> cmbStatus = new JComboBox<>(new String[]{"ALL", "UNPAID", "PAID"});
    private final JLabel lblSummary = new JLabel(" ");
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Bill ID", "Customer", "Meter No", "Period", "Prev", "Curr", "Units",
                    "Water (Rs.)", "Service (Rs.)", "Total (Rs.)", "Status", "Paid On"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(model);
    private List<Bill> bills = new ArrayList<>();

    public PaymentPanel() {
        setLayout(new BorderLayout(8, 8));
        setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        JButton btnSearch = new JButton("Search");
        top.add(new JLabel("Customer (name / meter no / id):"));
        top.add(txtSearch);
        top.add(new JLabel("Status:"));
        top.add(cmbStatus);
        top.add(btnSearch);
        btnSearch.addActionListener(e -> load());
        txtSearch.addActionListener(e -> load());
        cmbStatus.addActionListener(e -> load());
        add(top, BorderLayout.NORTH);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.setRowHeight(22);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton btnView = new JButton("View Bill");
        JButton btnPay = new JButton("Mark as Paid");
        btnView.addActionListener(e -> viewBill());
        btnPay.addActionListener(e -> payBill());
        JPanel bottom = new JPanel(new BorderLayout());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        buttons.add(btnView);
        buttons.add(btnPay);
        bottom.add(lblSummary, BorderLayout.WEST);
        bottom.add(buttons, BorderLayout.EAST);
        add(bottom, BorderLayout.SOUTH);

        load();
    }

    private void load() {
        try {
            bills = dao.search(txtSearch.getText(), (String) cmbStatus.getSelectedItem());
        } catch (SQLException e) {
            Dialogs.error(this, e);
            return;
        }
        model.setRowCount(0);
        BigDecimal due = BigDecimal.ZERO;
        for (Bill b : bills) {
            model.addRow(new Object[]{b.getId(), b.getCustomerName(), b.getMeterNo(),
                    BillFormatter.monthName(b.getMonth()) + " " + b.getYear(),
                    b.getPreviousReading(), b.getCurrentReading(), b.getUnitsConsumed(),
                    b.getWaterCharge(), b.getServiceCharge(), b.getTotalAmount(),
                    b.getStatus(), b.getPaidDate() == null ? "-" : b.getPaidDate().toString()});
            if ("UNPAID".equals(b.getStatus())) {
                due = due.add(b.getTotalAmount());
            }
        }
        lblSummary.setText("Bills shown: " + bills.size() + "   |   Outstanding: Rs. " + due);
    }

    private Bill selectedBill() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Dialogs.warn(this, "Select a bill from the table first.");
            return null;
        }
        return bills.get(table.convertRowIndexToModel(row));
    }

    private void viewBill() {
        Bill b = selectedBill();
        if (b == null) {
            return;
        }
        JTextArea ta = new JTextArea(BillFormatter.format(b));
        ta.setEditable(false);
        ta.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        JScrollPane sp = new JScrollPane(ta);
        sp.setPreferredSize(new Dimension(470, 330));
        JOptionPane.showMessageDialog(this, sp, "Bill #" + b.getId(), JOptionPane.PLAIN_MESSAGE);
    }

    private void payBill() {
        Bill b = selectedBill();
        if (b == null) {
            return;
        }
        if ("PAID".equals(b.getStatus())) {
            Dialogs.info(this, "This bill is already paid.");
            return;
        }
        if (!Dialogs.confirm(this, "Record payment of Rs. " + b.getTotalAmount()
                + " for " + b.getCustomerName() + "?")) {
            return;
        }
        try {
            if (dao.markPaid(b.getId())) {
                Dialogs.info(this, "Payment recorded.");
            }
            load();
        } catch (SQLException e) {
            Dialogs.error(this, e);
        }
    }

    @Override
    public void refresh() {
        load();
    }
}
