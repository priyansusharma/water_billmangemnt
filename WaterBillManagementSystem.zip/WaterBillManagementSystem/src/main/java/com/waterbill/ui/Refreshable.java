package com.waterbill.ui;

/** Implemented by tabs that reload their data when they are shown. */
public interface Refreshable {
    void refresh();
}
