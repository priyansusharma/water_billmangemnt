package com.waterbill.ui;

import com.waterbill.dao.RateDAO;
import com.waterbill.model.Slab;
import com.waterbill.util.Dialogs;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Map;

/** Read-only view of the predefined rates stored in the database. */
public class TariffPanel extends JPanel implements Refreshable {

    private final RateDAO dao = new RateDAO();

    private final DefaultTableModel slabModel = readOnlyModel(
            new String[]{"Connection Type", "From (units above)", "Up to (units)", "Rate per Unit (Rs.)"});
    private final DefaultTableModel chargeModel = readOnlyModel(
            new String[]{"Connection Type", "Fixed Service Charge (Rs.)"});

    public TariffPanel() {
        setLayout(new BorderLayout(8, 8));
        setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel grid = new JPanel(new GridLayout(2, 1, 8, 8));
        JScrollPane s1 = new JScrollPane(new JTable(slabModel));
        s1.setBorder(BorderFactory.createTitledBorder("Slab rates"));
        JScrollPane s2 = new JScrollPane(new JTable(chargeModel));
        s2.setBorder(BorderFactory.createTitledBorder("Service charges"));
        grid.add(s1);
        grid.add(s2);

        add(grid, BorderLayout.CENTER);
        add(new JLabel("Rates are stored in the 'rates' and 'service_charges' tables - edit them in MySQL to change the tariff."),
                BorderLayout.SOUTH);
        refresh();
    }

    private static DefaultTableModel readOnlyModel(String[] columns) {
        return new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    @Override
    public void refresh() {
        try {
            slabModel.setRowCount(0);
            for (Slab s : dao.getAllSlabs()) {
                slabModel.addRow(new Object[]{s.getConnectionType(), s.getFrom(),
                        s.getTo() == null ? "No limit" : s.getTo(), s.getRate()});
            }
            chargeModel.setRowCount(0);
            for (Map.Entry<String, BigDecimal> e : dao.getAllServiceCharges().entrySet()) {
                chargeModel.addRow(new Object[]{e.getKey(), e.getValue()});
            }
        } catch (SQLException e) {
            Dialogs.error(this, e);
        }
    }
}
