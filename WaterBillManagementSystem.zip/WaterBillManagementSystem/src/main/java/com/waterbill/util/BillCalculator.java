package com.waterbill.util;

import com.waterbill.model.Slab;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/** Calculates the water charge from the consumed units using slab rates. */
public class BillCalculator {

    private BillCalculator() {
    }

    /**
     * Example (DOMESTIC: 0-100 @5, 100-300 @8, 300+ @12) for 150 units:
     * 100 x 5 + 50 x 8 = 900.00
     *
     * @param slabs must be sorted by slab start (ascending)
     */
    public static BigDecimal waterCharge(int units, List<Slab> slabs) {
        BigDecimal total = BigDecimal.ZERO;
        for (Slab s : slabs) {
            if (units <= s.getFrom()) {
                break;
            }
            int upper = (s.getTo() == null) ? units : Math.min(units, s.getTo());
            int unitsInSlab = upper - s.getFrom();
            total = total.add(s.getRate().multiply(BigDecimal.valueOf(unitsInSlab)));
        }
        return total.setScale(2, RoundingMode.HALF_UP);
    }
}
