package com.waterbill.util;

import com.waterbill.model.Bill;

import java.time.Month;
import java.time.format.TextStyle;
import java.util.Locale;

/** Builds the printable text of a bill. */
public class BillFormatter {

    private BillFormatter() {
    }

    public static String monthName(int month) {
        return Month.of(month).getDisplayName(TextStyle.FULL, Locale.ENGLISH);
    }

    public static String format(Bill b) {
        String thick = "==============================================\n";
        String thin = "----------------------------------------------\n";
        StringBuilder sb = new StringBuilder();
        sb.append(thick);
        sb.append("              WATER BILL RECEIPT\n");
        sb.append(thick);
        sb.append(row("Bill No", b.getId() == 0 ? "(not generated yet)" : String.valueOf(b.getId())));
        sb.append(row("Customer", b.getCustomerName() + " (ID " + b.getCustomerId() + ")"));
        sb.append(row("Meter No", b.getMeterNo()));
        sb.append(row("Connection", b.getConnectionType()));
        sb.append(row("Billing Period", monthName(b.getMonth()) + " " + b.getYear()));
        sb.append(thin);
        sb.append(row("Previous Reading", String.valueOf(b.getPreviousReading())));
        sb.append(row("Current Reading", String.valueOf(b.getCurrentReading())));
        sb.append(row("Units Consumed", String.valueOf(b.getUnitsConsumed())));
        sb.append(thin);
        sb.append(row("Water Charge", "Rs. " + b.getWaterCharge()));
        sb.append(row("Service Charge", "Rs. " + b.getServiceCharge()));
        sb.append(row("TOTAL AMOUNT", "Rs. " + b.getTotalAmount()));
        sb.append(thin);
        String status = b.getStatus();
        if ("PAID".equals(status) && b.getPaidDate() != null) {
            status = status + " on " + b.getPaidDate();
        }
        sb.append(row("Status", status));
        sb.append(thick);
        return sb.toString();
    }

    private static String row(String label, String value) {
        return String.format("%-18s: %s%n", label, value);
    }
}
